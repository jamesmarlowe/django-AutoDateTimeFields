django-AutoDateTimeFields
=========================

django date time fields that don't break like auto_now and auto_now_add do

Contributors:
James Marlowe https://github.com/jamesmarlowe
